---
title: "XD"
date: 2020-06-07T05:04:00Z
draft: false
description: "Adobe XD is a vector-based user experience design tool for web apps and mobile apps, developed and published by Adobe Inc. "

weight: 1
categories: ["Design Tools"]

thumbnail: "images/tools/xd.jpg"
tools_website_link: "https://figma.com/"

tools_info:
- title: "Types :"
  content: "Design Tool, Prototype, Development Tools, App, Software"
- title: "Colors :"
  content: "Blue, Purple, White, Orange"

tools_images:
- image: "images/tools/figma.jpg"
- image: "images/tools/figma-lg.jpg"
---

## What Is Figma??
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas officiis cumque, harum dicta neces sita tisbus reprehenderit, delectus molestiae, impedit alias adipisci distinctio voluptas. Tempora modi amet voluptate at provident soluta consequatur.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quibud sdam sed, neque recusandae, est odit. A facere olorem quidem similique, delectus rerum laborum tempore soluta 


Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt, rem eaque facilis. Sit, voluptas? Errdvs zsor soluta odio, harum tenetur, alias in iure ipsam blanditiis illo, ratione, magnam a minima incidunt! Susd scipit quidem odit, quasi eveniet reprehenderit rerum dolorem voluptate sed aspernatur numquam enim, adipiasci iste optio ea libero laboriosam praesentium aperiam nobis vero olorem quidem similique, deleaca scctus


### Collaboration in Figma Is Simple and Familiar
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Purus, donec nunc eros, ullamcorper id feugiat quisque aliquam sagittis. Sem turpis sed viverra massa gravida pharetra. Non dui dolor potea adanti eu dignissim fusce. Ultrices amet, in curabitur a arcu a lectus morbi id. Iaculis erat sagittis in tortor cursus. 

Molestie urna eu tortor, erat scelerisque eget. Nunc hendrerit sed interdum lacus. Lorem quis viverra sed
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Purus, donec nunc eros, ullamcorper id feugiat 


### Figma Works on Any Platform
1. Sll the Themefisher items are designed to be with the latest , We check Impliments.
2. comments that threaten or harm the reputation of any person or organization.
3. personal information including, but  limited to, email addresses, telephone numbers.
4. Any Update come in The technology  Customer will get automatic  Notification.