---
title: "Classic"
layout: "classic"

banner:
  bg_image: "images/banner/banner-bg.svg"
  title: "Hi, I'm John Smith Doe. <br> I help people to make the  worlds best software"
  image: "images/banner/illustration.svg"
---