---
title: "Creative"
layout: "creative"

banner:
  bg_image: "images/about-banner.svg"
  title: "Hi, I'm Cameron William <br> My Blogsite is About <br> <strong>Website & Development</strong>"
  image: "images/banner-image.png"
---