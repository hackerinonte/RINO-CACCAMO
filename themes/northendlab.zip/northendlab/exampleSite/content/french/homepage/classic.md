---
title: "Classic"
layout: "classic"

banner:
  bg_image: "images/banner/banner-bg.svg"
  title: "Salut je suis John Smith Doe. <br> J'aide les gens à créer le meilleur logiciel du monde"
  image: "images/banner/illustration.svg"
---