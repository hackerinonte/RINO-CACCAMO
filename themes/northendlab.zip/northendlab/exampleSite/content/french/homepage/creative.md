---
title: "Creative"
layout: "creative"

banner:
  bg_image: "images/about-banner.svg"
  title: "Salut je suis Cameron William <br> Mon blog est sur <br> <strong>Site Web et Développement</strong>"
  image: "images/banner-image.png"
---